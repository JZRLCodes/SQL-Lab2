package org.example;

import jakarta.persistence.*;
import java.util.Scanner;
import java.io.*;

public class App
{
    private static EntityManagerFactory emf = Persistence.createEntityManagerFactory("SQL-Lab2");

    public static void main( String[] args )
    {
        Scanner scanner = new Scanner(System.in);
        addCustomer( "Test1","Company1", "647-900-0000", "Manager" );
        //addEmployee( "Test5","Test6" );
        //addEmployee( "James","Anderson" );
        //addEmployee( "Shaun","Pollock" );
        //addEmployee( "Hansi","Cronje" );
        getCustomer("BERGS");
        emf.close();
    }

    public static void addCustomer(String contactName, String companyName, String phoneNumber, String conTitle){
        EntityManager em = emf.createEntityManager();
        EntityTransaction et = null;
        try{
            et = em.getTransaction();
            et.begin();

            Employee emp = new Employee();
            emp.setCustomerId("ZZTEST");
            emp.setContactName(contactName);
            emp.setCompanyName(companyName);
            emp.setPhone(phoneNumber);
            emp.setCity("Toronto");
            emp.setPostalCode("M3A 2G1");
            emp.setAddress("123 Main St");
            emp.setRegion("ON");
            emp.setCountry("Canada");
            emp.setFax("123 456 7890");
            emp.setContactTitle(conTitle);


            em.persist(emp);
            et.commit();
        }catch (Exception ex){
            if(et!=null){
                et.rollback();
            }
        }finally {
            em.close();
        }
    }

    // show customer details
    public static void getCustomer(String id){
        EntityManager em = emf.createEntityManager();
        try{

            TypedQuery<Employee> tq = em.createQuery("select e from Employee e where e.customerId=:id", Employee.class);
            tq.setParameter("id", id);
            Employee emp = tq.getSingleResult();
            System.out.println("\nCustomer ID: " + emp.getCustomerId()+
                                "\nCompany Name: " + emp.getCompanyName()+
                                "\nContact Name: "+emp.getContactName()+
                                "\nContact Title: "+emp.getContactTitle()+
                                "\nAddress: "+emp.getAddress()+
                                "\nCity: "+emp.getCity()+
                                "\nPostal Code: "+emp.getPostalCode()+
                                "\nRegion: "+emp.getRegion()+
                                "\nCountry: "+emp.getCountry()+
                                "\nPhone Number: "+ emp.getPhone()+
                                "\nFax Number: "+ emp.getFax());
        }catch(Exception ex){
            ex.printStackTrace();
        }finally {
            {
                em.close();
            }
        }
    }

    //  delete customer
    public static void delCustomer(String id) {
        EntityManager em = emf.createEntityManager();
        try {

            TypedQuery<Employee> tq = em.createQuery("select e from Employee e where e.customerId=:id", Employee.class);
            tq.setParameter("id", id);
            Employee emp = tq.getSingleResult();

            System.out.println("\nCustomer ID: " + emp.getCustomerId() + " has been deleted");
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            {
                em.close();
            }
        }
    }


}